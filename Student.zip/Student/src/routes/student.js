const express = require('express');
// const { validationResult } = require('express-validator');
const Mongoose  = require('mongoose');
const {body, validationResult} = require('express-validator');
const studentModel = require('../model/student');
const app = express.Router();
const Student = require("../model/student");

app.get("/", async(req, res) => {

    try {
        const allStudent = await Student.find ();
        res.send(allStudent)
    } catch (error) {
        console.log("Error", error)
        res.status(500).send("Error getting Students")
    }
});


app.get("/:id", async(req, res) => {                             //to get one particular student's detail
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)){
       return res.status(400).send("Invalid ID");
    }
    try {
        const student = await Student.findById(id);
        if (student) {
            res.send(student);
            
        } else {
             res.status(404).send("Student not found");
        }
    } catch (error) {
        console.log ("Error", error);
        res.status(500).send("Error getting student");
    }
});


app.post("/", 
body('name').isString().isLength({min: 5, max:20}). withMessage('value for name is not valid')
,
async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
       return res.status(400).send(errors);
    }
    console.log(req.body);
    const student = new Student(req.body);

    try {
        const newStudent = await student.save()
        res.send(newStudent)
    } catch (error) {
        console.log("Error", error)
        res.status(500).send("Error creating student");
    } 
});


app.put("/:id", async(req, res) => {
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)){
       return res.status(400).send("Invalid ID");
    }
    try {
        const student = await Student.findByIdAndUpdate(id, req.body, { new: true });
        console.log(student);
        res.send(student);

    } catch (error) {
        console.log("Error", error);
        res.status(500).send("Error updating student");
    }
});


app.delete("/:id", async(req, res) => {
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)){
       return res.status(400).send("Invalid ID");
    }

    try {
        const student = await Student.findByIdAndDelete(id);

        if (student) {
            res.send("Student Deleted");

        } else {
            res.status(404).send("Student not found");
        }
        
    } catch (error) {
        console.log("Error", error);
        res.status(500).send("Error deleting student");
    }
});



module.exports = app;