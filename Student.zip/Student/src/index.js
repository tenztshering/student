const express = require('express');
const mongoose = require('mongoose');
const studentRouter = require("./routes/student");
const app = express();

const cors = require("cors");

app.use(cors());

app.use(express.json()); //to get the detail from client in json function.
app.use(express.urlencoded({extended: true}));
app.use("/student", studentRouter);

app.get("/student", (req, res) => {
    res.send('GET ALL');
    console.log("req.body");
})
app.get("/student/:id", (req, res) => {
    res.send('GET' + req.params.id);
});
app.post("/student", (req, res) => {
    console.log(req.body);
    res.send('POST');
    
});
app.put("/student/:id", (req, res) => {
    res.send('PUT');
});
app.delete("/student/:id", (req, res) => {
    res.send('DELETE');
});


const start = async () =>{
    const mongoURI = "mongodb://localhost:27017";

    try {
        await mongoose.connect(mongoURI,{
            useNewUrlParser: true
        });
        
        app.listen(3000, () => console.log('Server started'));

    } catch (error) {
        console.log("Error starting server", error)
        
    }
    };

start();
