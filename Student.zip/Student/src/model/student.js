const mongoose = require("mongoose");
// const validator = require("validator");

const desuungSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },

    age: {
        type: Number,
        required: true,
        min: 18,
        max: 40,
    },
    
    gender: {
        type: String,
        required: true,
    },

    score: {
        type: Number,                                        
        required: true,
        min: 0,
        max: 100,
    },

    registeredOn: {
        type: Date,
        default: new Date(),
    },
    });

const desuungModel = mongoose.model("desuungModel", desuungSchema);
module.exports = desuungModel;